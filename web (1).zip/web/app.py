import os
import numpy as np
import pandas as pd
import joblib
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)


try:
    winner_model = joblib.load('model/winner_model.pkl')
    home_goals_model = joblib.load('model/home_goals_model.pkl')
    away_goals_model = joblib.load('model/away_goals_model.pkl')
    
     
    
    teams = ['England', 'Brazil', 'Germany', 'France', 'Spain', 'Italy', 'Argentina', 'Netherlands', 
             'Portugal', 'Belgium', 'Uruguay', 'Colombia', 'Mexico', 'Switzerland', 'Croatia']
    
    tournaments = ['Friendly', 'World Cup', 'Euro', 'Copa America', 'Nations League', 
                  'World Cup Qualification', 'Euro Qualification', 'Confederations Cup']
    
    cities = ['London', 'Paris', 'Berlin', 'Madrid', 'Rome', 'Rio de Janeiro', 'Buenos Aires', 
             'Amsterdam', 'Lisbon', 'Brussels', 'Montevideo', 'Bogota', 'Mexico City', 'Zurich', 'Zagreb']
    
    countries = ['England', 'France', 'Germany', 'Spain', 'Italy', 'Brazil', 'Argentina', 
                'Netherlands', 'Portugal', 'Belgium', 'Uruguay', 'Colombia', 'Mexico', 'Switzerland', 'Croatia']
    
   
    def encode_feature(value, feature_list):
        if value in feature_list:
            return feature_list.index(value)
        return 0  
    
    print("Models loaded successfully!")
except Exception as e:
    print(f"Error loading models: {e}")
    winner_model = None
    home_goals_model = None
    away_goals_model = None

@app.route('/')
def home():
    return render_template('index.html', 
                           teams=teams,
                           tournaments=tournaments,
                           cities=cities,
                           countries=countries)

@app.route('/predict', methods=['POST'])
def predict():
    try:
        
        home_team = request.form.get('home_team')
        away_team = request.form.get('away_team')
        tournament = request.form.get('tournament')
        city = request.form.get('city')
        country = request.form.get('country')
        year = int(request.form.get('year'))
        month = int(request.form.get('month'))
        day = int(request.form.get('day'))
        neutral = request.form.get('neutral') == 'true'
        
        
        home_team_encoded = encode_feature(home_team, teams)
        away_team_encoded = encode_feature(away_team, teams)
        tournament_encoded = encode_feature(tournament, tournaments)
        city_encoded = encode_feature(city, cities)
        country_encoded = encode_feature(country, countries)
        
       
        new_match = pd.DataFrame({
            'home_team': [home_team_encoded],
            'away_team': [away_team_encoded],
            'tournament': [tournament_encoded],
            'city': [city_encoded],
            'country': [country_encoded],
            'year': [year],
            'month': [month],
            'day': [day],
            'neutral': [neutral],
            'total_goals': [3],  
            'winner': [0]  
        })
        
        
        try:
            
            X_columns = winner_model.feature_names_in_ if hasattr(winner_model, 'feature_names_in_') else None
            
            if X_columns is not None:
                
                new_match = new_match.reindex(columns=X_columns, fill_value=0)
            
            predicted_winner = int(winner_model.predict(new_match)[0])
            predicted_home_goals = max(0, round(home_goals_model.predict(new_match)[0]))
            predicted_away_goals = max(0, round(away_goals_model.predict(new_match)[0]))
            
            
            if predicted_winner == 1 and predicted_home_goals <= predicted_away_goals:
                predicted_home_goals = predicted_away_goals + 1  
            elif predicted_winner == 0 and predicted_away_goals <= predicted_home_goals:
                predicted_away_goals = predicted_home_goals + 1 
            elif predicted_winner == 2 and predicted_home_goals != predicted_away_goals:
                predicted_away_goals = predicted_home_goals  
            
            
            outcome_labels = {1: "Home Win", 0: "Away Win", 2: "Draw"}
            predicted_outcome = outcome_labels[predicted_winner]
            
            try:
                proba = winner_model.predict_proba(new_match)[0]
                home_win_probability = f"{proba[1]:.2%}" if len(proba) > 1 else "N/A"
                away_win_probability = f"{proba[0]:.2%}" if len(proba) > 0 else "N/A"
                draw_probability = f"{proba[2]:.2%}" if len(proba) > 2 else "N/A"
            except:
                
                home_win_probability = "N/A"
                away_win_probability = "N/A"
                draw_probability = "N/A"
            
            result = {
                'home_team': home_team,
                'away_team': away_team,
                'predicted_outcome': predicted_outcome,
                'predicted_score': f"{predicted_home_goals} - {predicted_away_goals}",
                'home_win_probability': home_win_probability,
                'away_win_probability': away_win_probability,
                'draw_probability': draw_probability
            }
            
            return render_template('result.html', result=result)
        
        except Exception as model_error:
            print(f"Model prediction error: {model_error}")
    
            result = {
                'home_team': home_team,
                'away_team': away_team,
                'predicted_outcome': "Unable to predict (Model error)",
                'predicted_score': "? - ?",
                'home_win_probability': "N/A",
                'away_win_probability': "N/A",
                'draw_probability': "N/A",
                'error': str(model_error)
            }
            return render_template('result.html', result=result)
    
    except Exception as e:
        print(f"General error: {e}")
        return render_template('error.html', error=str(e))

if __name__ == '__main__':
    app.run(debug=True)